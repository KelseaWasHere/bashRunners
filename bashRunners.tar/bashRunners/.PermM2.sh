#!/bin/bash
#reset permissions when game is transported to a new user

chmod 000 .Machine2/Downloads/Apps/Zmail.exe

