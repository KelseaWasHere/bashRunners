#!/bin/bash
chmod 777 Machine2/Downloads/Apps/Zmail.exe
