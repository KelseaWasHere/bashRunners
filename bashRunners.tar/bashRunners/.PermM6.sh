#!/bin/bash
#reset permissions when game is transported to a new user
chmod 000 .Machine6/Settings/.Accounts
chmod 000 .Machine6/Settings/.System
chmod 000 .Machine6/Settings/.Devices
chmod 000 .Machine6/Settings/.Privacy
